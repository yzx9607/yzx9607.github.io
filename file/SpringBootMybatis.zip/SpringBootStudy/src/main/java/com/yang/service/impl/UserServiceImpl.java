package com.yang.service.impl;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yang.bean.User;
import com.yang.dao.UserDao;
import com.yang.service.IUserService;

/**
 * 服务实现
 * @author Yang
 *
 */
@Service //标识为服务类
public class UserServiceImpl implements IUserService {
	//注入数据层接口
	@Autowired
	private UserDao userDao;
	
	@Override
	public List<User> getUser() {
		return userDao.getUser();
	}

}
